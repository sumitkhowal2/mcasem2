const cluster = require('cluster');
const http = require('http');
const numCPUs = require('os').cpus().length;

if (cluster.isMaster) {
  // Code for the master process

  console.log(`Master process (PID: ${process.pid}) is running`);

  // Fork workers for each CPU core
  for (let i = 0; i < numCPUs; i++) {
    cluster.fork();
  }

  // Listen for exit event to fork a new worker if one exits
  cluster.on('exit', (worker, code, signal) => {
    console.log(`Worker process ${worker.process.pid} has exited. Restarting...`);
    cluster.fork();
  });
} else {
  // Code for worker processes

  console.log(`Worker process ${process.pid} is running`);

  // Create an HTTP server in each worker process
  http.createServer((req, res) => {
    res.writeHead(200);
    res.end('Hello from Worker!');
  }).listen(5000);
}
