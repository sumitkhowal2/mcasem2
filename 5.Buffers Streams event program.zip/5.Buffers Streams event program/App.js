const fs = require('fs');
const EventEmitter = require('events');

// Create a custom event emitter instance
const eventEmitter = new EventEmitter();

// Create a readable stream to read from a text file
const readableStream = fs.createReadStream('input.txt');

// Create a Buffer to accumulate data
let buffer = Buffer.alloc(0);

// Listen for the 'data' event from the readable stream
readableStream.on('data', (chunk) => {
  // Concatenate the data chunks into the buffer
  buffer = Buffer.concat([buffer, chunk]);
});

// Listen for the 'end' event from the readable stream
readableStream.on('end', () => {
  // Emit a custom 'processData' event with the processed content
  eventEmitter.emit('processData', buffer.toString());
});

// Define an event listener for the custom 'processData' event
eventEmitter.on('processData', (data) => {
  console.log('Processed Data:');
  console.log(data);
});

