#main file here import module file

from my_module import file
def main():
    name = input("Enter your name: ")
    files = file(name)
    print(files)

main()
