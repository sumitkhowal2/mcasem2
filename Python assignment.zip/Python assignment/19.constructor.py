class Student:
    def __init__(self,name,age,grade):
        self.name = name
        self.age = age
        self.grade = grade

    def displayInfo(self):
        print(f"Name of Student: {self.name}")
        print(f"Age of Student : {self.age}")
        print(f"Gade : {self.grade}")

s1 = Student("Sumit Khowal",23,"A+")
s2 = Student("Roshni",22,"B")
print("Student 1 : ")
s1.displayInfo()
print("Student 2 : ")
s2.displayInfo()
