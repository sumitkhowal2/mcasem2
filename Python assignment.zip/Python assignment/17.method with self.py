class Car:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year
        self.speed = 0

    def start(self):
        print(f"{self.year} {self.make} {self.model} is starting.")

    def accelerate(self):
        self.speed += 10
        print(f"Accelerating... Current speed: {self.speed} mph")

    def brake(self):
        if self.speed > 0:
            self.speed -= 10
            print(f"Braking... Current speed: {self.speed} mph")
        else:
            print("The car is already at a complete stop.")

# Create an instance of the Car class
car_make = input("Enter car make : ")
car_model = input("Enter model: ")
car_year = input("Enter Year: ")
my_car = Car(car_make, car_model, car_year)

# Perform actions on the car object
my_car.start()
my_car.accelerate()
my_car.accelerate()
my_car.accelerate()
my_car.brake()
my_car.brake()
my_car.brake()
my_car.brake()
