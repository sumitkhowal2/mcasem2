class Animal:
    def __init__(self,name):
        self.name = name

    def speak(self):
        pass
        #the pass statement is used to indicate that this method is intentionally empty

class Dog(Animal):
    def speak(self):
        return f"{self.name} says bark!"

class Cat(Animal):
    def speak(self):
        return f"{self.name} says Meow!"
dog = Dog("Dazy")
cat = Cat("Minky")

print(dog.speak())
print(cat.speak())
