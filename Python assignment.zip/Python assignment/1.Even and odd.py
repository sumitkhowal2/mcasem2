# This is program of finding Even or odd
def main():
    num = int(input("Enter  number: "))

    if num%2==0:
        print("This is even number")
    else:
        print("This is odd number")

if __name__ == "__main__":
    main()
