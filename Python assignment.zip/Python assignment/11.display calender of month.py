import calendar

year = int(input("Enter year: "))
month = int(input("Enter Month b/w 1 to 12 : "))

if 1<= month <=12 :
    cal = calendar.month(year,month)
    print("\n Calendar for {} / {} \n " .format(month,year))
    print(cal)
else:
    print("Invalid month. Please enter a month between 1 and 12.")
    
