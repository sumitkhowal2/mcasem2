def main():
    #creating tuple
    fruits = ("apple","mango","pear","orange","grapes")
    #access items in tuples
    print("First fruit: ",fruits[0])
    print("Third fruit: ",fruits[2])
    #Slincing a tuple
    print("Sliced fruits: ",fruits[2:5])
    #Length of tuple
    print("Number of fruits: ",len(fruits))
    #checking if an elements is present or not in tuple
    if "apple" in fruits:
        print("Yes,'apple' is in the tuple")
    else:
        print("'apple' is not in the tuple")

    # Concatenating tuples
    more_fruits = ("mango", "kiwi", "pineapple")
    all_fruits = fruits + more_fruits
    print("All fruits:", all_fruits)

if __name__ == "__main__":
    main()
