# program of copy items ot anoter file
def main():
    input_file_name=input("Enter the name of the input file: ")
    try:
        with open(input_file_name,'r') as input_file:
            content = input_file.read()

            output_file_name=input("Enter the name of the output file: ")

            with open(output_file_name,'w') as output_file:
                output_file.write(content)
            print("File contents copied successfully.")


    except FileNotFoundError:
        print("Input file not found!")

main()
