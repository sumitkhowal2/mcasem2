def print_lines_in_reverse(file_path):
    try:
        with open(file_path,'r') as file:   #with is ensure the file is close after reading (autometically close the file)
            lines = file.readlines()
            lines.reverse()

            for line in lines:
                print(line.strip()[::-1])  #strip remove whitespace

    except FileNotFoundError:
        print("File not found!")

def main():
    file_path = input("Enter the path of the file: ")
    print_lines_in_reverse(file_path)

if __name__ == "__main__":
    main()
