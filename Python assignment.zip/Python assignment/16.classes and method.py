class BankAccount:
    def __init__(self,account_number,holder_name,balance = 0.0):
        self.account_number = account_number
        self.holder_number = holder_name
        self.balance = balance
        #the 'self' keyword is used to refer to the instance of the class itself. 
     #creating deposit Method
    def deposit(self,amount):
        if amount > 0:
            self.balance += amount
            print(f" Deposited ${amount} into account {self.account_number} . New balance: ${self.balance:.2f}")
        else:
            print("Invalid deposit amount. Amount must be greater than zero.")

    #creating withdraw method
    def withdraw (self,amount):
        if 0 < amount <= self.balance:
            self.balance -= amount
            print(f"Withdraw ${amount} from account {self.account_number} .New balance : ${self.balance : .2f}")
        else:
            print("Invalid withdrawal amount or insufficient funds.")
    #creating display method
    def display_balance(self):
        print(f"Account {self.account_number} balance: ${self.balance:.2f}")
    
# Create two bank accounts
account1 = BankAccount("1003", "Sumit")
account2 = BankAccount("1002", "Roshni", 1000.0)

# Perform transactions
account1.display_balance()
d_amount = int(input("Enter amount to deposit : "))
account1.deposit(d_amount)
w_amount = int(input("Enter amount to withdraw : "))
account1.withdraw(w_amount)

account2.display_balance()
account2.deposit(1000.0)
account2.withdraw(1500.0)

account1.display_balance()
account2.display_balance()
