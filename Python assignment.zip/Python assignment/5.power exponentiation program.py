#This is program of power exponentiation with operator and function

def custom_operator(base,exponent):
    #using result =1 bcz power of 0 is equal to 1
    result = 1
    # underscore(_) is used to repeat the code
    for _ in range(exponent):
        result *=base
    return result
def power_function(base,exponent):
    return base**exponent

b = float(input("Enter the Base number : "))
e = int(input("Enter the exponent number: "))

using_operator = custom_operator(b,e)
using_function = power_function(b,e)
print(f"{b} raised to the power {e} is : {using_operator}","(Using operator)")
print(f"{b} raised to the power {e} is : {using_function}","(Using power function)")
        
