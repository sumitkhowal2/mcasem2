first= int(input("enter first number: "))
operator = input("+,-,*,/,%: ")
second = int(input("Enter second number: "))
if operator == "+":
    result = first + second
    print(f"Addition: {result}")
elif operator =="-":
    result = first - second
    print(f"Substraction: {result}")
elif operator =="*":
    result = first * second
    print(f"Multiple: {result}")
elif operator =="/":
    result = first // second
    print(f"Division {result}")
elif operator =="%":
    result = first % second
    print(f"Mod: {result}")
else:
    print("Invalid operation!")
