def count_and_read(file_path):
    try:
        with open(file_path,'r') as file:   #with is ensure the file is close after reading
            content = file.readlines()
            num_char = sum(len(line) for line in content) #characters in file
            num_words = sum(len(line.split()) for line in content)
            num_lines = len(content)

            num_lines_actual = sum(1 for line in content if line.strip())

            print("Number of Characters: ",num_char)
            print("Number of words: ",num_words)
            print("Number of lines: ",num_lines_actual)

    except FileNotFoundError:
        print("File not found!")

def main():
    file_path = input("Enter the path of the file: ")
    count_and_read(file_path)

if __name__ == "__main__":
    main()
