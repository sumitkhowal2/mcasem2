# file of module
def file(name):
    return f"Hello {name} !"
