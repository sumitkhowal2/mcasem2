def find_unique_and_duplicate(items):
    unique_items = []
    duplicate_items = []
    seen = set()   #set is used to store unique items

    for item in items:
        if item not in seen:
            unique_items.append(item)
            seen.add(item)
        else:
            duplicate_items.append(item)

    return unique_items, duplicate_items

def main():
    input_string = input("Enter a list of items separated by spaces: ")
    items = input_string.split()

    unique_items, duplicate_items = find_unique_and_duplicate(items)

    print("Unique items:", unique_items)
    print("Duplicate items:", duplicate_items)

if __name__ == "__main__":
    main()
