my_list = [1,2,3,4,5,6,7,8,9,10]
start_index = 4
end_index = 8
slice_list = my_list[start_index:end_index]
print("Original List : ",my_list)
print("Sliced List : ",slice_list)
