class count:
    counter = 0

    def __init__(self):
        count.counter +=1
c1 = count()
c2 = count()
c3 = count()
c4 = count()

print("Number of Objects created : " ,count.counter)
