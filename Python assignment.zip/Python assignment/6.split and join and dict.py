# This is split and join method and trace birthday

def main():
    sentence =input("Enter string to split: ")
    words = sentence.split()  #Split the sentence into words
    new_sentence = '-'.join(words) #Join the words with '-'
    print("Original Sentence: ",sentence)
    print("Modified sentence: ",new_sentence)

    #Using a dictionary to store birthdays
    birthdays = {
        "sumit" : "10 March",
        "khushboo" : "26 July",
        "manan" : "11 May",
        "udit": "15 Auguest"
        }
    while True:
        name = input("Enter a name( or 'exit' to quit): ")
        if name.lower() == "exit":
            print("Program is terminated")
            break
        elif name in birthdays:
            print(f"{name}'s birthday is on {birthdays[name]}")
        else:
            print(f"{name}'s birthday is not in the dictionary.")
            
if __name__ == "__main__":
    main()
