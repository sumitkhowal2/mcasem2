 import java.util.Vector;
 
 public class VectorUse {
  public static void main(String args[]){
  //create a vector of string
  Vector<String> vector = new Vector<>();
  vector.add("Apple ");
  vector.add("Banana ");
  vector.add("Cherry ");
  vector.add("Orange ");
  vector.add("Watermelon");
  
  System.out.println("Elements in the Vector: ");
  for (String fruit: vector){
    System.out.println(fruit);
  }
  }
 }
