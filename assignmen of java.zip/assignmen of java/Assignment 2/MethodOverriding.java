class Vehicle {
    void run()
    {
        System.out.println("Vehicle is running.");
    }
}
class Bike extends Vehicle{
    @Override

    void run(){
        System.out.println("Bike is not safe to Travel.");
    }
}
class MethodOverriding{
    public static void main(String args[])
    {
        Bike ob1 = new Bike();
        ob1.run();
        Vehicle ob2 = new Bike();
        ob2.run();
        Vehicle ob3 = new Vehicle();
        ob3.run();
  
    }
}
