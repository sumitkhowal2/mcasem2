import java.util.Arrays;

public class SortingString {
    public static void main(String[] args) {

        String str = "I am sumit Khowal From MCA";
        
        // convert the string to character aarry
        char[] charArray = str.toCharArray();

        // to sort 
        Arrays.sort(charArray);
        String sortedstr = new String (charArray);


        System.out.println("Original String : \n"+str);
        System.out.println(" Sorted String : \n"+ sortedstr);
 	}
}

    

