abstract class Shape{
  protected int length;
  protected int width;
  public Shape(int length,int width){
    this.length = length;
    this.width = width;
  }
  public abstract void printArea();
} 
class Rectangle extends Shape{
  public Rectangle(int length,int width){
    super(length,width);
  }
  @Override
  public void printArea(){
    int area=length*width;
    System.out.println("Rectange Area: " + area);
  }
}
class Triangle extends Shape{
  public Triangle(int length,int width){
    super(length,width);
  }
  @Override
  public void printArea(){
    double area = 0.5 *length * width;
    System.out.println("Triangle Area: " + area);
  }
}
class Circle extends Shape{
  public Circle(int radius){
    super(radius,radius);
    }
    @Override
    public void printArea(){
      double area = Math.PI * length * length;
      String formattedArea = String.format("%.2f", area);
      System.out.println("Circle Area: "+ formattedArea);
  }
}
public class ShapeTest {
  public static void main(String args[]){
    Shape rectangle = new Rectangle(5,4);
    Shape triangle = new Triangle(6,3);
    Shape circle = new Circle(5);
    System.out.println("The calculated Areas of Rectangle,Triangle and Circle : ");
    rectangle.printArea();
    triangle.printArea();
    circle.printArea();
  }
}
