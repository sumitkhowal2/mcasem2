import java.util.*;
class Roots {
  public static void main(String args[]){
    double r1,r2;  //ax^2+bx+c=0
    Scanner input = new Scanner(System.in);
    System.out.println("Enter the coefficients a,b and c: ");
    System.out.print("a: ");
    double a = input.nextDouble();
     System.out.print("b: ");
    double b = input.nextDouble();
     System.out.print("c: ");
    double c = input.nextDouble();
    //d = discriminant
    double d = (b*b) - (4*a*c);
    if(d==0) //real and equal
    {
      System.out.println("Roots are Real and Equal.");
      r1=r2= -b/(2*a);
      System.out.println("R1= " +r1);
      System.out.println("R2= " +r2);
    }
    else if(d>0) // real and distinct
    {
       System.out.println("Roots are real and distinct.");
       r1 = (-b + Math.sqrt(d))/(2*a);
        r2 = (-b - Math.sqrt(d))/(2*a);
        System.out.println("R1= " +r1);
      System.out.println("R2= " +r2);
    }
    else   //distinct and imaginary
    {
      System.out.println("Roots are distinct and imaginary.");
      double x = -b/(2*a);
      double y = Math.sqrt(-d)/(2*a);
      System.out.println("R1= " +x + "+i" + y);
      System.out.println("R2= " + x + "-i" + y);
    }
  }
} 
