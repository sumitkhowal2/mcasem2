// final class
final class motor{
    // final varible
     final String model = "Mahindra";
     // final method
   public final void start()
    {
        System.out.println("Vehicle Started.");

    }
}

class Bike {
    public final void start()
    {
        System.out.println("Bike Started.");
    }
}
public class FinalVariable {
    public static void main(String[] args) {

        motor mo = new motor();

      System.out.println("Model : " +mo.model);  
      mo.start();

      Bike bike = new Bike();
      bike.start();
    }
    
}
