//define an interface
interface Interface {
    void draw();

}
class Shape {
    void describe(){
      System.out.println("This is a shape");
    }
}
// Define a class Circle that extends shape and implement Interface class
class Circle extends Shape implements Interface {
    @Override
    public void draw(){
      System.out.println("Drawing a circle.");
    }
}

public class Main{
    public static void main(String args[]){
       Circle circle = new Circle();
       circle.describe();
       circle.draw();
    }
}
