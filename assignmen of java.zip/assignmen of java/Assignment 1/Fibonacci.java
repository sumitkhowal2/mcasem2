import java.util.*;
class Fibonacci {
	public static int fibonacciRecursive(int n){
	  if(n<=1){return n;}
	  else{
	    return fibonacciRecursive(n-1) + fibonacciRecursive(n-2);
	  }}
	public static void fibonacciNonRecursive(int n){
	  int[] fibonacciArray = new int[n];
	  fibonacciArray[0] =1;
	  fibonacciArray[1] =1;
	  System.out.println("Fibonacci Sequence for Non-Recursive Method: ");
	  for(int i=2;i<n;i++){
	    fibonacciArray[i] = fibonacciArray[i-1] + fibonacciArray[i-2];
	  }
	  for(int i=0; i<n;i++){
	    System.out.println(fibonacciArray[i] + " ");
	  }
	   System.out.println();
	}
	public static void main(String args[]){
	Scanner num = new Scanner(System.in);
	  System.out.print("Enter value of n: ");
	   int n = num.nextInt();
	  System.out.println("Fibonacci Sequence for Recursive Method : ");
	  for(int i=0;i<n;i++){
	    System.out.println(fibonacciRecursive(i) + " ");
	  }
	  System.out.println();
    fibonacciNonRecursive(n);
	}}
