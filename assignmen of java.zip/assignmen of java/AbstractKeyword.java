abstract class Motorcar{
    String msg;

    Motorcar(String msg)
    {
        this.msg = msg;
    }

    void display()
    {
        System.out.println(msg);
    }
}
  class HondaGadi extends Motorcar{
    HondaGadi(String msg)
    {
        super(msg);
    }
 }
public class AbstractKeyword {
    public static void main(String[] args) {
       
        HondaGadi ob = new HondaGadi("This is Example of Abstract Keyword.");
        ob.display();
    }
}
