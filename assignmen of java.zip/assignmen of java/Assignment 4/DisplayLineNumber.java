 import java.io.BufferedReader;
 import java.io.FileReader;
 import java.io.IOException;
 
 public class DisplayLineNumber{
  public static void main(String args[]){
    String filePath = "ReadFile.txt";
    try{
      FileReader fileReader = new FileReader(filePath);
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      String line;
      int lineNumber = 1;
      while((line = bufferedReader.readLine()) != null){
        System.out.println(lineNumber + ": " + line);
        lineNumber++;
      }
            bufferedReader.close();
    }catch(IOException e){
      e.printStackTrace();
    }
  }
 }
