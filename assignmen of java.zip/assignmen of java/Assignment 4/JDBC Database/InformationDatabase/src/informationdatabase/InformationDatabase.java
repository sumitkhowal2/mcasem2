package informationdatabase;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InformationDatabase {
    public static void main(String[] args) throws Exception {
        int choice =-1;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        DbConnection con = new DbConnection();
        do{
            System.out.println();
            System.out.println("--------------------------------");
            System.out.println("1.Insert Data");
            System.out.println("2.Display Data");
            System.out.println("3.Update Data");
            System.out.println("4.Delete Data");
            System.out.println("5.Exit");
            System.out.println("--------------------------------");
            System.out.println("Enter your choice: ");
            choice = Integer.parseInt(br.readLine());
            System.out.println();
            
                switch (choice) {
                case 1 -> {
                    System.out.print("Enter number of input Data: ");
                    int n = Integer.parseInt(br.readLine());
                    for(int i=0;i<n;i++){
                        System.out.print("Enter Roll number: ");
                        int rollno = Integer.parseInt(br.readLine());
                        
                        System.out.print("Enter Name: ");
                        String name =br.readLine();
                        
                        System.out.print("Enter Age: ");
                        int age = Integer.parseInt(br.readLine());
                        
                        System.out.print("Enter Branch: ");
                        String branch =br.readLine();
                        
                        con.insert(rollno,name,age,branch);
                    }
                }
                case 2 -> {
                    System.out.println("Roll no.      Name \t\t Age \tBranch ");
                    System.out.println("----------------------------------------");
                    con.display();
                }
                case 3 -> {
                    System.out.print("Enter Roll number to update: ");
                    int rollno = Integer.parseInt(br.readLine());
                    
                    System.out.print("Enter new  Name: ");
                    String name =br.readLine();
                    
                    System.out.print("Enter new Age: ");
                    int age = Integer.parseInt(br.readLine());
                    
                    System.out.print("Enter new Branch: ");
                    String branch =br.readLine();
                    
                    con.update(rollno,name,age,branch);
                }
                case 4 -> {
                    System.out.print("Enter Roll number to delete: ");
                    int rollno = Integer.parseInt(br.readLine());
                    con.delete(rollno);
                }
                case 5 -> con.close();
                    
            }
        }while(choice!=0);
        
       
       
    }
    
}

class DbConnection {
     Connection con;
     PreparedStatement ps;
     ResultSet rs;
    DbConnection(){
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin://@localhost:1521:xe","sumit","manager");
            System.out.println("Connection Established.");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void insert(int rollno,String name,int age,String branch) throws SQLException{
        ps =con.prepareStatement("insert into info(rollno,name,age,branch) values(?,?,?,?)");
        ps.setInt(1, rollno);
        ps.setString(2, name);
        ps.setInt(3, age);
        ps.setString(4, branch);
        ps.executeUpdate();
        System.out.println("Record Inserted");
    }
    public void display() throws SQLException{
        ps = con.prepareStatement("SELECT * FROM INFO");
        rs= ps.executeQuery();
        while(rs.next()){
            System.out.printf("%-15s%-20s%5s%5s\n",rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
        }
    }
     public void update(int rollno,String name,int age,String branch) throws SQLException{
        ps =con.prepareStatement("update info set name=?,age=?,branch=? where rollno=?");
        ps.setInt(4, rollno);
        ps.setString(1, name);
        ps.setInt(2, age);
        ps.setString(3, branch);
        ps.executeUpdate();
        System.out.println("Record Updated.");
    }
     public void delete(int rollno) throws SQLException{
        ps =con.prepareStatement("DELETE FROM INFO WHERE ROLLNO = ?");
        ps.setInt(1, rollno);
        ps.executeUpdate();
        System.out.println("Record Deleted.");
    }
    public void close() throws Exception {
        con.close();
        System.out.println("Connection closed.");

    }  
}
