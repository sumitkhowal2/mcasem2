import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Phonebook {
    public static void main(String[] args) {
        String filePath = "phonebook.txt"; 
        Map<String, String> phonebook = new HashMap<>();

        try {
            FileReader fileReader = new FileReader(filePath);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;

            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split("\\s+"); 
                if (parts.length == 2) {
                    String name = parts[0];
                    String phoneNumber = parts[1];
                    phonebook.put(name, phoneNumber);
                }
            }

            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a name or phone number to search: ");
        String input = scanner.nextLine().trim(); 

        if (phonebook.containsKey(input)) {
            String result = phonebook.get(input);
            System.out.println("Name: " + input + ", Phone Number: " + result);
        } else if (phonebook.containsValue(input)) {
            for (Map.Entry<String, String> entry : phonebook.entrySet()) {
                if (entry.getValue().equals(input)) {
                    String result = entry.getKey();
                    System.out.println("Phone Number: " + input + ", Name: " + result);
                }
            }
        } else {
            System.out.println("Entry not found.");
        }
        scanner.close();
    }
}

