 import java.io.BufferedReader;
 import java.io.FileReader;
 import java.io.IOException;
 
 public class FileState{
  public static void main(String args[]){
    String filePath = "ReadFile.txt";
    try{
      FileReader fileReader = new FileReader(filePath);
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      int charCount = 0;
      int lineCount = 0;
      int wordCount = 0;
      String line;
      while((line = bufferedReader.readLine()) != null){
        //characters count
        charCount += line.length();
        //line count
        lineCount++;
        //words count
        String[] words = line.split("\\s+");
        wordCount += words.length;
      }
      System.out.println("Number of characters: " + charCount);
            System.out.println("Number of lines: " + lineCount);
            System.out.println("Number of words: " + wordCount);

            bufferedReader.close();
    }catch(IOException e){
      e.printStackTrace();
    }
  }
 }
