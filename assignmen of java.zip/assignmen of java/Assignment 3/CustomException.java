// Define a custom exception class
class NegativeNumberException extends Exception {
    public NegativeNumberException(String message) {
        super(message);
    }
}

public class CustomException{
    public static void main(String[] args) {
        try {
            int number = -5;
            if (number < 0) {
                throw new NegativeNumberException("Number cannot be negative");
            }
            System.out.println("Number: " + number);
        } catch (NegativeNumberException e) {
            System.out.println("Custom exception caught: " + e.getMessage());
        }

        System.out.println("Program continues after exception handling.");
    }
}

