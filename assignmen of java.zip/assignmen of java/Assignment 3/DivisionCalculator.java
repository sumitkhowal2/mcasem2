 import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DivisionCalculator {
    private JFrame frame;
    private JPanel panel;
    private JTextField num1Field;
    private JTextField num2Field;
    private JButton divideButton;
    private JLabel resultLabel;

    public DivisionCalculator() {
        // Create the JFrame and JPanel
        frame = new JFrame("Integer Division Calculator");
        panel = new JPanel();

        // Create input fields, button, and result label
        num1Field = new JTextField(10);
        num2Field = new JTextField(10);
        divideButton = new JButton("Divide");
        resultLabel = new JLabel("Result:");

        // Add components to the panel
        panel.add(new JLabel("Num1:"));
        panel.add(num1Field);
        panel.add(new JLabel("Num2:"));
        panel.add(num2Field);
        panel.add(divideButton);
        panel.add(resultLabel);

        // Add action listener to the Divide button
        divideButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int num1 = Integer.parseInt(num1Field.getText());
                    int num2 = Integer.parseInt(num2Field.getText());

                    // Handle division by zero
                    if (num2 == 0) {
                        throw new ArithmeticException("Division by zero");
                    }

                    int result = num1 / num2;
                    resultLabel.setText("Result: " + result);
                } catch (NumberFormatException ex) {
                    // Handle NumberFormatException
                    JOptionPane.showMessageDialog(frame, "Invalid input. Please enter valid integers.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (ArithmeticException ex) {
                    // Handle ArithmeticException (division by zero)
                    JOptionPane.showMessageDialog(frame, "Division by zero is not allowed.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Set layout and add panel to the frame
        frame.setLayout(new BorderLayout());
        frame.add(panel, BorderLayout.CENTER);

        // Set frame properties
        frame.setSize(300, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new DivisionCalculator();
            }
        });
    }
}

