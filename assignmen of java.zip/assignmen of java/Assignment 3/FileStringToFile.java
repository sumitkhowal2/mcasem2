import java.io.FileOutputStream;
import java.io.IOException;

public class FileStringToFile{
    public static void main(String[] args) {
        String content = "Hello, Sumit is writing to the file by FileOutputStream.";

        // Specify the file path
        String filePath = "output.txt";

        try (FileOutputStream fos = new FileOutputStream(filePath)) {
            // Convert the string to bytes and write it to the file
            byte[] bytes = content.getBytes();
            fos.write(bytes);

            System.out.println("String has been written to the file.");
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }
}

