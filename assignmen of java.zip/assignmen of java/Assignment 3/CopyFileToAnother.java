import java.io.*;

public class CopyFileToAnother {
    public static void main(String[] args) {
        // Specify the source file path
        String sourceFilePath = "input.txt"; // Change this to the path of your source file

        // Specify the destination file path
        String destinationFilePath = "destination.txt"; // Change this to the path of your destination file

        try (FileReader fileReader = new FileReader(sourceFilePath);
             BufferedReader bufferedReader = new BufferedReader(fileReader);
             FileWriter fileWriter = new FileWriter(destinationFilePath);
             BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                bufferedWriter.write(line);
                bufferedWriter.newLine(); // Add a newline character to separate lines in the destination file
            }

            System.out.println("File copied successfully.");
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }
}

