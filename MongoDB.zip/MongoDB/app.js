require('dotenv').config(); // Load environment variables from .env
const express = require('express');
const mongoose = require('mongoose');

const app = express();
const port = process.env.PORT || 3000;
const dburl = process.env.dburl; // Get MongoDB connection URL from .env

async function checkMongoDBConnection() {
  try {
    await mongoose.connect(dburl, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    }); // Attempt to connect to MongoDB using Mongoose
    console.log('MongoDB connected successfully');
  } catch (error) {
    console.error('Error connecting to MongoDB:', error);
  }
}

// Initialize the Express server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
//Define the index type and index name
const loginSchema = new mongoose.Schema({
  name:{
    type:String,
    required:true
  },
  password:{
    type:String,
    required:true
  }
});
//Store the record in the data ,data1
const collection = new mongoose.model('login',loginSchema);
data ={
  name:"Imran",
  password:"MCASEMESTER2"
}
data1 ={
  name:"sumit",
  password:"PTANHIKYAPASSWORDHAI"
}
//Insert the record into the Database
collection.insertMany([data]);
collection.insertMany([data1]);
// Check the MongoDB connection when the server starts
checkMongoDBConnection();
console.log('Data Inserted successully.');

