//Import the express.js framework
const express = require('express');
//creating an express application
const app = express();

app.get('/',(req,res) => {
   res.send(' <h1> Hello World! </h1>');
   });
   
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
   console.log(`Server is ready to run on port ${PORT}`);
   });
 
